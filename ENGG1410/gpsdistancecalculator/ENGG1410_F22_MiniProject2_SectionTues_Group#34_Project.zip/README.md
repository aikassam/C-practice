# engg1410miniproject2final

This project was completed by Aiman Kassam for the Introductory Programming for Engineering Course (ENGG 1410) at the University of Guelph.

In mini project 2, students were to create a program capable of calculating distances between users, and sorting the information to return the nearest user to yourself.

For this program, you have the option to input values manually or with a text file. For manual input, the program will guide you to insert names and position coordinates of users. If you wish to input with a text file, organize the file such that the first number is an integer for the number of users. Following the number of users should be the person's name, time, latitude, longitude, and altitude in that exact order. Ensure that every value is on a new line. For file input you will need to know the text file's directory. 

The output of this program will be the name and position coordinates of the user nearest to yourself, given the position coordinates of all users provided.